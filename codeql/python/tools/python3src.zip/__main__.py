from __future__ import print_function, division

import semmle.populator

if __name__ == "__main__":
    semmle.populator.main()
