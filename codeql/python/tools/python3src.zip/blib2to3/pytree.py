
__author__ = 'Guido van Rossum <guido@python.org>'
import sys
from io import StringIO
HUGE = 2147483647
_type_reprs = {}

def type_repr(type_num):
    global _type_reprs
    if (not _type_reprs):
        from .pygram import python_symbols
        for (name, val) in python_symbols.__dict__.items():
            if (type(val) == int):
                _type_reprs[val] = name
    return _type_reprs.setdefault(type_num, type_num)
